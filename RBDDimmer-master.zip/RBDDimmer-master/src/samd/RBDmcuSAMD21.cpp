#if defined(ARDUINO_ARCH_SAMD)

#include "RBDmcuSAMD21.h"

 void dimmer_zero_cross_isr(void);
 
int dim_tim[10];
int dim_max[10];

//int dim_begin = 90;
int pulseWidth = 2;
volatile int current_dim = 0;
int all_dim = 3;
int rise_fall = true;
char user_zero_cross = '0';

static int toggleCounter = 0;
static int toggleReload = 25;

static dimmerLamp* dimmer[ALL_DIMMERS];
volatile uint16_t dimPower[ALL_DIMMERS];
volatile uint16_t dimOutPin[ALL_DIMMERS];
volatile uint16_t zeroCross[ALL_DIMMERS];
volatile DIMMER_MODE_typedef dimMode[ALL_DIMMERS];
volatile ON_OFF_typedef dimState[ALL_DIMMERS];
volatile uint16_t dimCounter[ALL_DIMMERS];
static uint16_t dimPulseBegin[ALL_DIMMERS];
volatile uint16_t togMax[ALL_DIMMERS];
volatile uint16_t togMin[ALL_DIMMERS];
volatile bool togDir[ALL_DIMMERS];

dimmerLamp::dimmerLamp(int user_dimmer_pin):
	dimmer_pin(user_dimmer_pin)
{
	current_dim++;
	dimmer[current_dim-1] = this;
	current_num = current_dim-1;
	toggle_state = false;
	
	dimPulseBegin[current_dim-1] = 1;
	dimOutPin[current_dim-1] = user_dimmer_pin;
	dimCounter[current_dim-1] = 0;
	zeroCross[current_dim-1] = 0;
	dimMode[current_dim-1] = NORMAL_MODE;
	togMin[current_dim-1] = 0;
	togMax[current_dim-1] = 1;
	pinMode(user_dimmer_pin, OUTPUT);
	__enable_irq();
}
 
void dimmerLamp::timer_init(void)
{
    // 1. Turn on the power for the TC3 Timer
    PM->APBCMASK.reg |= PM_APBCMASK_TC3;

    // 2. Connect TC3 to the Main 48MHz Clock (GCLK0)
    GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN |        // Enable
                        GCLK_CLKCTRL_GEN_GCLK0 |    // Connect to 48MHz Source
                        GCLK_CLKCTRL_ID_TCC2_TC3;   // Connect to TC3
    while (GCLK->STATUS.bit.SYNCBUSY);              // Wait for sync

    // 3. Reset the timer to start fresh
    TC3->COUNT8.CTRLA.reg = TC_CTRLA_SWRST;
    while (TC3->COUNT8.STATUS.bit.SYNCBUSY);
    while (TC3->COUNT8.CTRLA.bit.SWRST);

    // 4. Configure the Timer
    // MODE_COUNT8:   8-bit mode (count to 255 max)
    // PRESCALER_DIV64: Slow down 48MHz by 64 -> 750kHz
    // WAVEGEN_MFRQ:  Match Frequency (Reset to 0 when we hit the target value)
    TC3->COUNT8.CTRLA.reg = TC_CTRLA_MODE_COUNT8 |
                            TC_CTRLA_PRESCALER_DIV64 |
                            TC_CTRLA_WAVEGEN_MFRQ;

    // 5. Set the Target Value (The "Tick" Speed)
    // 60Hz AC = 8.33ms half wave.
    // We want 100 dimming steps. 8.33ms / 100 = ~83us per step.
    // 750kHz clock = 1.33us per tick.
    // 83us / 1.33us = ~62.5 -> Round to 63.
    TC3->COUNT8.CC[0].reg = 63;  
    while (TC3->COUNT8.STATUS.bit.SYNCBUSY);

    // 6. Enable the Interrupt
    TC3->COUNT8.INTENSET.reg = TC_INTENSET_MC0;
    NVIC_EnableIRQ(TC3_IRQn);

    // 7. Start the Timer
    TC3->COUNT8.CTRLA.reg |= TC_CTRLA_ENABLE;
    while (TC3->COUNT8.STATUS.bit.SYNCBUSY);
}

void dimmerLamp::ext_int_init(void) 
{ 
    // Hard-coded to Pin 2 to force the correct "Doorbell" wiring
    pinMode(2, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(2), dimmer_zero_cross_isr, RISING);
}

void dimmerLamp::begin(DIMMER_MODE_typedef DIMMER_MODE, ON_OFF_typedef ON_OFF)
{
	dimMode[this->current_num] = DIMMER_MODE;
	dimState[this->current_num] = ON_OFF;
	timer_init();
	ext_int_init();	
}

void dimmerLamp::setPower(int power)
{	
	if (power >= 99) 
	{
		power = 99;
	}
	dimPower[this->current_num] = power;
	dimPulseBegin[this->current_num] = powerBuf[power];
	
	delay(1);
}

int dimmerLamp::getPower(void)
{
	if (dimState[this->current_num] == ON)
		return dimPower[this->current_num];
	else return 0;
}

void dimmerLamp::setState(ON_OFF_typedef ON_OFF)
{
	dimState[this->current_num] = ON_OFF;
}

bool dimmerLamp::getState(void)
{
	bool ret;
	if (dimState[this->current_num] == ON) ret = true;
	else ret = false;
	return ret;
}

void dimmerLamp::changeState(void)
{
	if (dimState[this->current_num] == ON) dimState[this->current_num] = OFF;
	else 
		dimState[this->current_num] = ON;
}

DIMMER_MODE_typedef dimmerLamp::getMode(void)
{
	return dimMode[this->current_num];
}

void dimmerLamp::setMode(DIMMER_MODE_typedef DIMMER_MODE)
{
	dimMode[this->current_num] = DIMMER_MODE;
}

void dimmerLamp::toggleSettings(int minValue, int maxValue)
{
	if (maxValue > 99) 
	{
    	maxValue = 99;
	}
	if (minValue < 1) 
	{
    	minValue = 1;
	}
	dimMode[this->current_num] = TOGGLE_MODE;
	togMin[this->current_num] = powerBuf[maxValue];
	togMax[this->current_num] = powerBuf[minValue];

	toggleReload = 50;
}

// 1. The Logic (Renamed from EIC_Handler)
void dimmer_zero_cross_isr(void)
{
    for (int i = 0; i < current_dim; i++ ) 
        if (dimState[i] == ON) 
        {
            zeroCross[i] = 1;
        }
}


static int k;
extern "C" void TC3_Handler(void)
{
	toggleCounter++;
	for (k = 0; k < current_dim; k++)
	{
		if (zeroCross[k] == 1 )
		{
			dimCounter[k]++;

			if (dimMode[k] == TOGGLE_MODE)
			{
			/*****
			 * TOGGLE DIMMING MODE
			 *****/
			if (dimPulseBegin[k] >= togMax[k]) 	
			{
				// if reach max dimming value 
				togDir[k] = false;	// downcount				
			}
			if (dimPulseBegin[k] <= togMin[k])
			{
				// if reach min dimming value 
				togDir[k] = true;	// upcount
			}
			if (toggleCounter == toggleReload) 
			{
				if (togDir[k] == true) dimPulseBegin[k]++;
				else dimPulseBegin[k]--;
			}
			}
			
			/*****
			 * DEFAULT DIMMING MODE (NOT TOGGLE)
			 *****/
			if (dimCounter[k] >= dimPulseBegin[k] )
			{
				digitalWrite(dimOutPin[k], HIGH);	
			}

			if (dimCounter[k] >=  (dimPulseBegin[k] + pulseWidth) )
			{
				digitalWrite(dimOutPin[k], LOW);
				zeroCross[k] = 0;
				dimCounter[k] = 0;
			}
		}
	}

	if (toggleCounter >= toggleReload) toggleCounter = 1;
	TC3->COUNT8.INTFLAG.reg = TC_INTFLAG_MC0;	// Acknowledge the interrupt (clear MC0 interrupt flag to re-arm)
}

#endif
